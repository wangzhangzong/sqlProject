/*
SQLyog Professional v12.09 (64 bit)
MySQL - 5.7.25 : Database - employee_exam
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`employee_exam` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;

USE `employee_exam`;

/*Table structure for table `t_score` */

DROP TABLE IF EXISTS `t_score`;

CREATE TABLE `t_score` (
  `sno` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `cno` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `degree` decimal(10,0) DEFAULT NULL,
  KEY `sno` (`sno`),
  KEY `cno` (`cno`),
  CONSTRAINT `t_score_ibfk_1` FOREIGN KEY (`sno`) REFERENCES `t_student` (`sno`),
  CONSTRAINT `t_score_ibfk_2` FOREIGN KEY (`cno`) REFERENCES `t_course` (`cno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `t_score` */

insert  into `t_score`(`sno`,`cno`,`degree`) values ('105','3-245','55'),('109','3-245','68'),('105','3-105','22'),('109','3-105','91'),('108','6-166','85'),('105','6-166','79'),('109','6-166','81'),('101','6-166','82'),('107','6-166','84'),('108','3-105','77');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
