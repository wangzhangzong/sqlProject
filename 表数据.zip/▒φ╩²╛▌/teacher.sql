/*
SQLyog Professional v12.09 (64 bit)
MySQL - 5.7.25 : Database - employee_exam
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`employee_exam` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;

USE `employee_exam`;

/*Table structure for table `t_teacher` */

DROP TABLE IF EXISTS `t_teacher`;

CREATE TABLE `t_teacher` (
  `tno` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '编号',
  `tname` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '姓名',
  `tsex` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '性别',
  `tbirthday` datetime DEFAULT NULL COMMENT '生日',
  `prof` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '职务',
  `depart` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '所在系别',
  `state` varchar(20) COLLATE utf8_unicode_ci DEFAULT '0',
  PRIMARY KEY (`tno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `t_teacher` */

insert  into `t_teacher`(`tno`,`tname`,`tsex`,`tbirthday`,`prof`,`depart`,`state`) values ('1006','齐全','男','1991-03-12 00:00:00','教授','计算机系','1'),('804','李诚','男','1958-12-02 00:00:00','副教授','计算机系','0'),('825','王萍','女','1972-05-05 00:00:00','助教','计算机系','0'),('831','刘冰','女','1977-08-14 00:00:00','助教','电子工程系','0'),('856','张旭','男','1969-03-12 00:00:00','讲师','电子工程系','0'),('871','李飞','男','2016-04-04 00:00:00','讲师','计算机系','0'),('886','王五','男','2018-04-04 00:00:00','讲师','计算机系','0'),('901','张三','男','1999-05-20 00:00:00','教授','电子工程系','0'),('931','刘备','男','2014-04-01 00:00:00','教授','计算机系','0'),('946','张飞','男','2018-04-04 00:00:00','讲师','计算机系','0'),('961','周红','女','2017-03-12 00:00:00','教授','计算机系','0'),('976','王能力','女','1993-03-12 00:00:00','研发工程师','研发部',NULL),('991','王盼盼','男','1991-03-12 00:00:00','教授','焊接',NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
